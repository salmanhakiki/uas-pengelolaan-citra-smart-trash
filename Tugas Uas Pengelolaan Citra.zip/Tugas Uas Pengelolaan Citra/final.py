import streamlit as st
import cv2
import numpy as np
from PIL import Image
from classifier import TrashClassifier
from serial_comm import get_esp

# ── Konfigurasi Halaman Streamlit ────────────────────────────
st.set_page_config(
    page_title="Smart Trash Sorter - EfficientNetB0",
    page_icon="♻️",
    layout="wide"
)

# ── Inisialisasi Model & Serial (Menggunakan Cache) ──────────
@st.cache_resource
def init_system():
    classifier = TrashClassifier()
    esp = get_esp()
    esp.connect()
    return classifier, esp

classifier, esp = init_system()

# ── Custom CSS untuk Tampilan Modern ─────────────────────────
st.markdown("""
    <style>
    .main-title { text-align: center; color: #1E3A8A; font-weight: bold; margin-bottom: 20px; }
    .pipeline-box { border: 2px solid #E5E7EB; padding: 10px; border-radius: 8px; text-align: center; background-color: #F9FAFB; }
    </style>
""", unsafe_allow_html=True)

st.markdown("<h1 class='main-title'>♻️ TEMPAT SAMPAH PINTAR</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center; margin-top:-20px;'>Berbasis <b>Computer Vision (EfficientNetB0)</b> dan <b>IoT (ESP8266)</b></p>", unsafe_allow_html=True)
st.divider()

# ── Sidebar Konfigurasi ──────────────────────────────────────
st.sidebar.header("⚙️ Konfigurasi Sistem")

mode_operasi = st.sidebar.radio(
    "Mode Operasi:",
    ["Simulasi (Tanpa Hardware)", "Hardware Nyata (USB Camera + ESP8266)"]
)

st.sidebar.subheader("🔌 Status ESP8266")
if esp.is_connected:
    if esp.is_simulation or "Simulasi" in mode_operasi:
        st.sidebar.warning("🤖 Mode Simulasi Aktif\n(Hardware tidak digunakan)")
    else:
        st.sidebar.success(f"✅ Terhubung pada Port: {esp.port}")
else:
    st.sidebar.error("❌ Terputus")

if st.sidebar.button("🔄 Hubungkan Ulang Hardware"):
    esp.connect()
    st.rerun()

# ── Main Layout ──────────────────────────────────────────────
col_input, col_status = st.columns([2, 1])

with col_input:
    st.subheader("📸 Input Citra Sampah")
    
    # Pilihan Input Kamera atau File Upload
    use_cam = st.checkbox("Gunakan Kamera Live/Webcam", value=True)
    img_file = None
    
    if use_cam:
        img_file = st.camera_input("Ambil Gambar Sampah")
    else:
        img_file = st.file_uploader("Unggah Gambar Sampah", type=["jpg", "jpeg", "png"])

# Proses klasifikasi jika ada input gambar
if img_file is not None:
    # Mengubah format gambar streamlit ke OpenCV (BGR)
    file_bytes = np.asarray(bytearray(img_file.read()), dtype=np.uint8)
    img_bgr = cv2.imdecode(file_bytes, 1)
    
    # ── PIPELINE PENGELOLAAN CITRA (4 TAHAP) ────────────────
    st.subheader("🔍 Pipeline Visualisasi Pengelolaan Citra (4 Tahap)")
    
    # 1. Citra Asli
    img_asli = img_bgr.copy()
    
    # 2. Enhancement (Peningkatan Kontras CLAHE / Brightness)
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    img_enhanced = clahe.apply(gray)
    
    # 3. Edge Detection (Deteksi Tepi Canny)
    img_blur = cv2.GaussianBlur(img_enhanced, (5, 5), 0)
    img_edges = cv2.Canny(img_blur, 50, 150)
    
    # Tampilkan 4 Tahap secara Horizontal
    p1, p2, p3 = st.columns(3)
    with p1:
        st.image(cv2.cvtColor(img_asli, cv2.COLOR_BGR2RGB), caption="1. Citra Asli", use_container_width=True)
    with p2:
        st.image(img_enhanced, caption="2. Gambar Lembut & Kontras", use_container_width=True)
    with p3:
        st.image(img_edges, caption="3. Deteksi Tepi (Canny)", use_container_width=True)
        
    # ── PROSES PREDIKSI AI (TAHAP 4) ────────────────────────
    with st.spinner("AI sedang menganalisis karakteristik objek..."):
        result = classifier.predict(img_bgr)
        cat = result["category"]
        info = result["info"]
        
    with col_status:
        st.subheader("📊 Hasil Klasifikasi AI")
        
        # Tampilkan box hasil akhir
        st.metric(label="Kategori Terdeteksi", value=info["label"])
        st.progress(result["confidence"], text=f"Confidence: {result['confidence_pct']}")
        
        # Deskripsi & Tindakan
        st.info(f"**Keterangan:** {info['description']}")
        st.success(f"**Aksi Mekanik:** {info['action']}")
        
        # Kirim perintah ke ESP8266 jika dalam mode Hardware Nyata
        if "Hardware Nyata" in mode_operasi:
            response_serial = esp.send_sort_command(cat)
            st.caption(f"🤖 Respon Balik Serial: {response_serial}")
        else:
            # Mode simulasi
            response_serial = esp.send_sort_command(cat)
            st.caption(f"🧪 Respon Simulasi: {response_serial}")
            
        # Tampilkan Detail Teknis ImageNet untuk Kebutuhan UAS
        with st.expander("📝 Detail Ekstraksi Fitur (Top Prediksi)"):
            st.write(f"**Metode Analisis:** `{result['method']}`")
            st.write(f"**Petunjuk Warna (HSV):** `{result['hsv_hint']}`")
            st.write("**Top 5 Kelas ImageNet Relevan:**")
            st.json(result["top5"])