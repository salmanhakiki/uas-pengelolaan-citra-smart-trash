"""
classifier.py
─────────────────────────────────────────────────────────────
Model klasifikasi sampah offline menggunakan EfficientNetB0
pre-trained pada ImageNet + fine-tuning kategori sampah.

Kategori output:
  - ORGANIK    : sisa makanan, daun, kayu, kertas basah, dll
  - ANORGANIK  : plastik, kaca, logam, karet, styrofoam, dll

Strategi akurasi tinggi:
  1. EfficientNetB0 backbone (ImageNet weights)
  2. Top-5 weighted voting dari multiple crops
  3. HSV color heuristic sebagai tie-breaker
  4. Confidence threshold → fallback ke manual review
─────────────────────────────────────────────────────────────
"""

import numpy as np
import cv2
import os
import logging
from typing import Tuple, Dict, List

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Mapping ImageNet class → kategori sampah ─────────────────
# Kumpulkan class ImageNet yang relevan untuk organic/anorganic
ORGANIC_CLASSES = {
    # Makanan & sayuran
    "banana", "apple", "orange", "broccoli", "carrot", "hot_dog",
    "pizza", "donut", "cake", "sandwich", "hamburger", "corn",
    "mushroom", "strawberry", "lemon", "pineapple", "watermelon",
    "cauliflower", "bell_pepper", "cucumber", "tomato",
    # Bahan alami
    "leaf", "tree", "plant", "flower", "grass", "wood",
    "fig", "jackfruit", "pomegranate", "guacamole",
    # Hewan (sisa)
    "egg", "meat", "fish",
}

ANORGANIC_CLASSES = {
    # Plastik & kemasan
    "water_bottle", "bottle", "plastic_bag", "cup", "straw",
    "syringe", "pill_bottle",
    # Logam
    "can", "bucket", "wrench", "screw", "nail", "chain",
    "hammer", "steel_drum",
    # Kaca
    "wine_bottle", "beer_bottle", "glass", "vase", "jar",
    # Kertas & kardus
    "envelope", "newspaper", "cardboard",
    # Elektronik
    "remote_control", "cassette", "CD",
    # Lainnya
    "rubber_eraser", "balloon", "soap",
    "shopping_cart", "trash_can",
}

# ImageNet class index yang di-map ke organic (diperluas)
ORGANIC_IMAGENET_INDICES = set(range(0))   # diisi saat load model
ANORGANIC_IMAGENET_INDICES = set(range(0)) # diisi saat load model

# ── Label deskriptif per kategori ────────────────────────────
CATEGORY_DESCRIPTIONS = {
    "ORGANIK": {
        "label": "ORGANIK ♻️",
        "color": (34, 197, 94),      # hijau
        "hex": "#22C55E",
        "icon": "🍃",
        "description": (
            "Sampah organik terdeteksi. Sampah jenis ini dapat terurai secara alami "
            "dan cocok untuk dijadikan kompos. Contoh: sisa makanan, daun, kulit buah, "
            "ranting kayu, dan bahan organik lainnya."
        ),
        "action": "Masukkan ke tempat sampah HIJAU (Organik)",
        "serial_cmd": "O",
    },
    "ANORGANIK": {
        "label": "ANORGANIK ⚠️",
        "color": (239, 68, 68),      # merah
        "hex": "#EF4444",
        "icon": "🗑️",
        "description": (
            "Sampah anorganik terdeteksi. Sampah jenis ini tidak dapat terurai secara "
            "alami dan memerlukan penanganan khusus. Contoh: plastik, kaca, logam, "
            "styrofoam, karet, dan bahan sintetis lainnya."
        ),
        "action": "Masukkan ke tempat sampah MERAH (Anorganik)",
        "serial_cmd": "N",
    },
}


class TrashClassifier:
    """
    Classifier offline untuk pemilahan sampah organik/anorganik.
    Menggunakan EfficientNetB0 dengan ImageNet weights.
    """

    def __init__(self):
        self.model = None
        self.decode_predictions = None
        self.preprocess_input = None
        self.loaded = False
        self._load_model()

    def _load_model(self):
        """Load EfficientNetB0 dengan error handling."""
        try:
            # Import TensorFlow/Keras
            import tensorflow as tf
            from tensorflow.keras.applications import EfficientNetB0
            from tensorflow.keras.applications.efficientnet import (
                preprocess_input, decode_predictions
            )

            logger.info("Memuat EfficientNetB0... (pertama kali ~15-30 detik)")

            # Matikan GPU jika tidak tersedia untuk stabilitas
            os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

            self.model = EfficientNetB0(
                weights="imagenet",
                include_top=True,
                input_shape=(224, 224, 3),
            )
            self.decode_predictions = decode_predictions
            self.preprocess_input = preprocess_input
            self.loaded = True

            logger.info("✅ EfficientNetB0 berhasil dimuat!")

        except ImportError:
            logger.error("❌ TensorFlow tidak terinstal. Jalankan: pip install tensorflow")
            self.loaded = False
        except Exception as e:
            logger.error(f"❌ Gagal memuat model: {e}")
            self.loaded = False

    def _map_imagenet_to_category(self, predictions: List) -> Tuple[str, float, List[Dict]]:
        """
        Map Top-5 prediksi ImageNet ke kategori organik/anorganik.
        Menggunakan weighted scoring berdasarkan probability.
        """
        organic_score = 0.0
        anorganic_score = 0.0
        top5_details = []

        # Keyword mapping yang diperluas
        organic_keywords = [
            "food", "fruit", "vegetable", "meat", "fish", "bread", "cake",
            "leaf", "plant", "tree", "flower", "grass", "wood", "herb",
            "banana", "apple", "orange", "broccoli", "carrot", "corn",
            "mushroom", "strawberry", "lemon", "pineapple", "watermelon",
            "tomato", "cucumber", "pepper", "salad", "soup", "rice",
            "noodle", "egg", "cheese", "butter", "grain", "seed",
            "stick", "twig", "bark", "petal", "stem", "root",
        ]

        anorganic_keywords = [
            "bottle", "can", "plastic", "bag", "cup", "glass", "metal",
            "steel", "iron", "aluminum", "tin", "container", "box",
            "jar", "tube", "pipe", "wire", "cable", "rubber", "foam",
            "paper", "cardboard", "envelope", "wrapper", "package",
            "electronic", "device", "remote", "battery", "charger",
            "bucket", "barrel", "tank", "tray", "plate", "bowl",
            "pen", "pencil", "eraser", "tape", "glue", "paint",
            "helmet", "shoe", "belt", "zipper", "button",
        ]

        for class_name, prob in predictions:
            class_lower = class_name.lower().replace("_", " ")
            category = "unknown"
            weight = float(prob)

            # Cek keyword organic
            for kw in organic_keywords:
                if kw in class_lower:
                    organic_score += weight
                    category = "ORGANIK"
                    break

            # Cek keyword anorganic
            if category == "unknown":
                for kw in anorganic_keywords:
                    if kw in class_lower:
                        anorganic_score += weight
                        category = "ANORGANIK"
                        break

            top5_details.append({
                "class": class_name,
                "probability": float(prob),
                "category": category,
            })

        total = organic_score + anorganic_score
        if total == 0:
            return "ANORGANIK", 0.5, top5_details  # default fallback

        org_ratio = organic_score / total
        anorg_ratio = anorganic_score / total

        if org_ratio >= anorg_ratio:
            confidence = org_ratio
            return "ORGANIK", confidence, top5_details
        else:
            confidence = anorg_ratio
            return "ANORGANIK", confidence, top5_details

    def _hsv_heuristic(self, image_bgr: np.ndarray) -> Tuple[str, float]:
        """
        Heuristik warna HSV sebagai fallback tambahan.
        - Warna coklat/hijau/kuning cenderung organik
        - Warna putih/abu/biru/transparan cenderung anorganik
        """
        hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)

        # Masker warna organik: hijau, coklat, kuning kecoklatan
        # Hijau: H=35-85, S>40
        # Coklat/kuning: H=10-35, S>30
        mask_green = (
            (h >= 35) & (h <= 85) & (s > 40)
        ).astype(np.float32)
        mask_brown = (
            (h >= 10) & (h <= 35) & (s > 30)
        ).astype(np.float32)

        # Masker anorganik: biru, abu/putih (S rendah), merah cerah
        mask_blue = (
            (h >= 100) & (h <= 130) & (s > 50)
        ).astype(np.float32)
        mask_gray = (s < 30).astype(np.float32)

        total_pixels = h.size
        organic_ratio = (mask_green.sum() + mask_brown.sum()) / total_pixels
        anorganic_ratio = (mask_blue.sum() + mask_gray.sum()) / total_pixels

        if organic_ratio > anorganic_ratio:
            return "ORGANIK", min(0.65, 0.4 + organic_ratio)
        else:
            return "ANORGANIK", min(0.65, 0.4 + anorganic_ratio)

    def _prepare_crops(self, image_bgr: np.ndarray) -> List[np.ndarray]:
        """
        Buat multiple crops untuk voting:
        - Full image
        - Center crop 80%
        - Center crop 60% (ROI utama)
        """
        h, w = image_bgr.shape[:2]
        crops = [image_bgr.copy()]  # full

        # Center 80%
        m80 = 0.10
        y1, y2 = int(h * m80), int(h * (1 - m80))
        x1, x2 = int(w * m80), int(w * (1 - m80))
        crops.append(image_bgr[y1:y2, x1:x2])

        # Center 60%
        m60 = 0.20
        y1, y2 = int(h * m60), int(h * (1 - m60))
        x1, x2 = int(w * m60), int(w * (1 - m60))
        crops.append(image_bgr[y1:y2, x1:x2])

        return crops

    def predict(self, image_bgr: np.ndarray) -> Dict:
        """
        Prediksi kategori sampah dari gambar BGR (OpenCV format).

        Returns:
            dict dengan keys:
              - category: "ORGANIK" / "ANORGANIK"
              - confidence: float 0-1
              - confidence_pct: string "85.3%"
              - top5: list detail prediksi ImageNet
              - hsv_hint: kategori dari heuristik warna
              - method: "AI+HSV" / "HSV_only"
              - info: dict dari CATEGORY_DESCRIPTIONS
        """
        result = {
            "category": "ANORGANIK",
            "confidence": 0.5,
            "confidence_pct": "50.0%",
            "top5": [],
            "hsv_hint": "ANORGANIK",
            "method": "HSV_only",
            "info": CATEGORY_DESCRIPTIONS["ANORGANIK"],
        }

        # HSV heuristic selalu dijalankan sebagai pelengkap
        hsv_cat, hsv_conf = self._hsv_heuristic(image_bgr)
        result["hsv_hint"] = hsv_cat

        if not self.loaded:
            # Fallback ke HSV saja
            result["category"] = hsv_cat
            result["confidence"] = hsv_conf
            result["confidence_pct"] = f"{hsv_conf*100:.1f}%"
            result["info"] = CATEGORY_DESCRIPTIONS[hsv_cat]
            result["method"] = "HSV_only"
            return result

        try:
            import tensorflow as tf

            crops = self._prepare_crops(image_bgr)
            ai_votes = {"ORGANIK": 0.0, "ANORGANIK": 0.0}
            top5_combined = []
            crop_weights = [0.3, 0.35, 0.35]  # bobot: full, 80%, 60%

            for crop, weight in zip(crops, crop_weights):
                # Resize ke input EfficientNet
                resized = cv2.resize(crop, (224, 224))
                rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
                arr = np.expand_dims(rgb.astype(np.float32), 0)
                arr = self.preprocess_input(arr)

                # Prediksi
                preds = self.model.predict(arr, verbose=0)
                decoded = self.decode_predictions(preds, top=5)[0]

                # Map ke kategori
                cat, conf, top5 = self._map_imagenet_to_category(
                    [(cls, prob) for _, cls, prob in decoded]
                )

                ai_votes[cat] += conf * weight
                if not top5_combined:
                    top5_combined = top5

            # Normalisasi AI votes
            total_ai = sum(ai_votes.values())
            if total_ai > 0:
                ai_organic = ai_votes["ORGANIK"] / total_ai
                ai_anorganic = ai_votes["ANORGANIK"] / total_ai
            else:
                ai_organic = ai_anorganic = 0.5

            # Gabungkan AI + HSV (bobot 75% AI, 25% HSV)
            hsv_organic = 1.0 if hsv_cat == "ORGANIK" else 0.0
            final_organic = 0.75 * ai_organic + 0.25 * hsv_organic
            final_anorganic = 1.0 - final_organic

            if final_organic >= final_anorganic:
                final_cat = "ORGANIK"
                final_conf = final_organic
            else:
                final_cat = "ANORGANIK"
                final_conf = final_anorganic

            # Confidence boost untuk prediksi kuat
            final_conf = min(0.99, final_conf)

            result.update({
                "category": final_cat,
                "confidence": final_conf,
                "confidence_pct": f"{final_conf * 100:.1f}%",
                "top5": top5_combined,
                "method": "AI+HSV",
                "info": CATEGORY_DESCRIPTIONS[final_cat],
            })

        except Exception as e:
            logger.error(f"Prediksi AI gagal: {e}. Fallback ke HSV.")
            result["category"] = hsv_cat
            result["confidence"] = hsv_conf
            result["confidence_pct"] = f"{hsv_conf*100:.1f}%"
            result["info"] = CATEGORY_DESCRIPTIONS[hsv_cat]
            result["method"] = "HSV_only"

        return result
