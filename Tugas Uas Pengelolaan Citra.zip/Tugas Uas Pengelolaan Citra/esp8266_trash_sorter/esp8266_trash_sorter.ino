/*
 * ============================================================
 *  SMART TRASH SORTER - ESP8266
 *  Hardware: ESP8266 + Servo + LCD I2C (16x2) + Buzzer
 *  Komunikasi: Serial USB (115200 baud)
 *  Perintah:
 *    'O' -> Organic   : Servo ke 45°,  buzzer 1x pendek
 *    'N' -> Anorganik : Servo ke 135°, buzzer 2x pendek
 *    'R' -> Reset     : Servo ke 90°  (posisi tengah/tutup)
 *    'P' -> Ping      : Balas "READY" (cek koneksi)
 * ============================================================
 */

#include <Arduino.h>
#include <Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ─── PIN KONFIGURASI ────────────────────────────────────────
#define SERVO_PIN   D5   // GPIO14
#define BUZZER_PIN  D6   // GPIO12

// ─── LCD I2C (alamat 0x27, ukuran 16x2) ────────────────────
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ─── SERVO ──────────────────────────────────────────────────
Servo trashServo;

// ─── POSISI SERVO (derajat) ─────────────────────────────────
const int POS_ORGANIC    = 45;   // Pintu organik terbuka
const int POS_ANORGANIC  = 135;  // Pintu anorganik terbuka
const int POS_RESET      = 90;   // Posisi tengah / tutup

// ─── BUZZER ─────────────────────────────────────────────────
void beep(int times, int duration_ms) {
  for (int i = 0; i < times; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(duration_ms);
    digitalWrite(BUZZER_PIN, LOW);
    if (i < times - 1) delay(150);
  }
}

// ─── LCD HELPER ─────────────────────────────────────────────
void lcdPrint(String line1, String line2 = "") {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(line1.substring(0, 16));
  if (line2.length() > 0) {
    lcd.setCursor(0, 1);
    lcd.print(line2.substring(0, 16));
  }
}

// ─── SETUP ──────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(100);

  // LCD
  Wire.begin(D2, D1);  // SDA=D2(GPIO4), SCL=D1(GPIO5)
  lcd.init();
  lcd.backlight();
  lcdPrint("Smart Trash", "  Sorter v1.0");
  delay(1500);

  // Servo
  trashServo.attach(SERVO_PIN);
  trashServo.write(POS_RESET);
  delay(500);

  // Buzzer
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  // Ready signal
  beep(1, 200);
  lcdPrint("Status: READY", "Menunggu...");
  Serial.println("READY");
}

// ─── LOOP ───────────────────────────────────────────────────
void loop() {
  if (Serial.available() > 0) {
    char cmd = Serial.read();

    switch (cmd) {

      case 'O':  // ORGANIK
        lcdPrint(">> ORGANIK <<", "Buang di sini!");
        trashServo.write(POS_ORGANIC);
        beep(1, 300);
        Serial.println("ACK:ORGANIC");
        delay(3000);
        trashServo.write(POS_RESET);
        lcdPrint("Status: READY", "Menunggu...");
        Serial.println("ACK:RESET");
        break;

      case 'N':  // ANORGANIK
        lcdPrint(">> ANORGANIK<<", "Buang di sini!");
        trashServo.write(POS_ANORGANIC);
        beep(2, 200);
        Serial.println("ACK:ANORGANIC");
        delay(3000);
        trashServo.write(POS_RESET);
        lcdPrint("Status: READY", "Menunggu...");
        Serial.println("ACK:RESET");
        break;

      case 'R':  // RESET MANUAL
        trashServo.write(POS_RESET);
        lcdPrint("Status: READY", "Menunggu...");
        Serial.println("ACK:RESET");
        break;

      case 'P':  // PING / CEK KONEKSI
        Serial.println("READY");
        break;

      default:
        // Abaikan karakter tidak dikenal
        break;
    }
  }
}
