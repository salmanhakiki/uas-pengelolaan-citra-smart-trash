@echo off
title Jalankan UAS Pengelolaan Citra - EfficientNetB0
mode con: cols=80 lines=15
color 0A

echo =======================================================
echo    MEMULAI SISTEM TEMPAT SAMPAH PINTAR EFFICIENTNET    
echo =======================================================
echo.
echo [1/2] Berpindah ke Drive E...
E:

echo [2/2] Masuk ke direktori projek...
cd "E:\Tugas Uas Pengelolaan Citra"

echo.
echo [OK] Menjalankan Streamlit pada Port 9999...
echo Silahkan cek browser kamu secara otomatis / buka http://localhost:9999
echo.
streamlit run final.py --server.port 9999

pause