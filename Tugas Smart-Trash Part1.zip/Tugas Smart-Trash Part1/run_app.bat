@echo off
title Smart Trash Sorter - RUN APP
color 0A

echo ============================================================
echo   MENJALANKAN SMART TRASH SORTER AI...
echo ============================================================
echo.
echo Memulai server Streamlit...
echo (Browser akan terbuka secara otomatis)
echo.

:: Menjalankan Streamlit
python -m streamlit run app.py

:: Jika terjadi error, biarkan terminal tetap terbuka
if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERROR] Gagal menjalankan aplikasi! Pastikan environment sudah disetup.
    pause
)