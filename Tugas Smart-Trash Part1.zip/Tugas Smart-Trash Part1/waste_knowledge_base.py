"""
waste_knowledge_base.py
================================================================
DATABASE PENGETAHUAN SAMPAH KOMPREHENSIF - INDONESIA
================================================================
Database ini memuat pemetaan ratusan objek ke kategori ORGANIK/ANORGANIK
dengan tingkat kepercayaan dan alasan ilmiah.

Sumber referensi:
- UU No. 18 Tahun 2008 tentang Pengelolaan Sampah
- Permen LHK No. P.75/MenLHK/Setjen/Kum.1/10/2019
- Standar klasifikasi sampah Indonesia
================================================================
"""

from typing import Dict, List, Tuple, Optional
import numpy as np

# ================================================================
# 1. MAPPING OBJEK → KATEGORI BERDASARKAN COCO/YOLO CLASSES
# ================================================================

# Mapping YOLO COCO classes → kategori sampah
YOLO_WASTE_MAPPING = {
    # === ORGANIK (dapat terurai secara alami) ===
    "banana":        ("ORGANIK", 0.98, "Buah dapat terurai secara alami"),
    "apple":         ("ORGANIK", 0.98, "Buah dapat terurai secara alami"),
    "orange":        ("ORGANIK", 0.98, "Buah dapat terurai secara alami"),
    "broccoli":      ("ORGANIK", 0.98, "Sayuran dapat terurai"),
    "carrot":        ("ORGANIK", 0.98, "Sayuran dapat terurai"),
    "pizza":         ("ORGANIK", 0.95, "Sisa makanan dapat terurai"),
    "cake":          ("ORGANIK", 0.95, "Sisa makanan dapat terurai"),
    "donut":         ("ORGANIK", 0.95, "Sisa makanan dapat terurai"),
    "sandwich":      ("ORGANIK", 0.95, "Sisa makanan dapat terurai"),
    "hot dog":       ("ORGANIK", 0.95, "Sisa makanan dapat terurai"),
    "bowl":          ("ANORGANIK", 0.85, "Wadah biasanya plastik/keramik"),  # context-dependent
    
    # === ANORGANIK (tidak dapat terurai/tidak terurai dalam waktu singkat) ===
    "bottle":        ("ANORGANIK", 0.97, "Botol plastik/kaca tidak terurai"),
    "wine glass":    ("ANORGANIK", 0.98, "Gelas kaca tidak terurai"),
    "cup":           ("ANORGANIK", 0.90, "Cup biasanya plastik/kertas bersih"),
    "fork":          ("ANORGANIK", 0.95, "Plastik/logam tidak terurai"),
    "knife":         ("ANORGANIK", 0.95, "Logam tidak terurai"),
    "spoon":         ("ANORGANIK", 0.95, "Plastik/logam tidak terurai"),
    "bowl":          ("ANORGANIK", 0.90, "Keramik/plastik tidak terurai"),
    "banana":        ("ORGANIK", 0.98, "Buah dapat terurai"),
    "apple":         ("ORGANIK", 0.98, "Buah dapat terurai"),
    "sandwich":      ("ORGANIK", 0.95, "Sisa makanan"),
    "orange":        ("ORGANIK", 0.98, "Buah dapat terurai"),
    "broccoli":      ("ORGANIK", 0.98, "Sayuran"),
    "carrot":        ("ORGANIK", 0.98, "Sayuran"),
    "hot dog":       ("ORGANIK", 0.95, "Sisa makanan"),
    "pizza":         ("ORGANIK", 0.95, "Sisa makanan"),
    "donut":         ("ORGANIK", 0.95, "Sisa makanan"),
    "cake":          ("ORGANIK", 0.95, "Sisa makanan"),
    "chair":         ("ANORGANIK", 0.95, "Kayu dilapisi/cat (tidak terurai)"),
    "couch":         ("ANORGANIK", 0.95, "Kain/sintetis tidak terurai"),
    "potted plant":  ("ORGANIK", 0.90, "Tanaman dapat terurai"),
    "bed":           ("ANORGANIK", 0.95, "Kain/kayu olahan"),
    "dining table":  ("ANORGANIK", 0.95, "Kayu olahan tidak terurai"),
    "toilet":        ("ANORGANIK", 0.98, "Keramik tidak terurai"),
    "tv":            ("ANORGANIK", 0.99, "Elektronik berbahaya"),
    "laptop":        ("ANORGANIK", 0.99, "Elektronik berbahaya"),
    "mouse":         ("ANORGANIK", 0.99, "Elektronik plastik"),
    "remote":        ("ANORGANIK", 0.99, "Elektronik/baterai"),
    "keyboard":      ("ANORGANIK", 0.99, "Elektronik plastik"),
    "cell phone":    ("ANORGANIK", 0.99, "Elektronik berbahaya"),
    "microwave":     ("ANORGANIK", 0.99, "Elektronik berbahaya"),
    "oven":          ("ANORGANIK", 0.99, "Logam elektronik"),
    "toaster":       ("ANORGANIK", 0.99, "Logam elektronik"),
    "sink":          ("ANORGANIK", 0.98, "Logam/stainless"),
    "refrigerator":  ("ANORGANIK", 0.99, "Elektronik besar berbahaya"),
    "book":          ("ANORGANIK", 0.85, "Kertas bersih (daur ulang)"),
    "clock":         ("ANORGANIK", 0.98, "Logam/baterai"),
    "vase":          ("ANORGANIK", 0.97, "Kaca/keramik"),
    "scissors":      ("ANORGANIK", 0.98, "Logam tajam"),
    "teddy bear":    ("ANORGANIK", 0.95, "Kain sintetis"),
    "hair drier":    ("ANORGANIK", 0.99, "Elektronik"),
    "toothbrush":    ("ANORGANIK", 0.98, "Plastik sintetis"),
}

# ================================================================
# 2. KEYWORD-BASED MAPPING UNTUK IMAGENET/EFFICIENTNET
# ================================================================

IMAGENET_ORGANIC_KEYWORDS = {
    # Buah-buahan (confidence tinggi)
    "banana": 0.99, "apple": 0.99, "orange": 0.99, "lemon": 0.99,
    "lime": 0.99, "grape": 0.99, "strawberry": 0.99, "blueberry": 0.99,
    "raspberry": 0.99, "pineapple": 0.99, "watermelon": 0.99, "melon": 0.99,
    "peach": 0.99, "pear": 0.99, "plum": 0.99, "cherry": 0.99,
    "mango": 0.99, "papaya": 0.99, "coconut": 0.99, "pomegranate": 0.99,
    "fig": 0.99, "date": 0.99, "avocado": 0.99, "kiwi": 0.99,
    
    # Sayuran (confidence tinggi)
    "broccoli": 0.99, "carrot": 0.99, "corn": 0.99, "cucumber": 0.99,
    "pepper": 0.95, "potato": 0.99, "onion": 0.99, "garlic": 0.99,
    "tomato": 0.99, "lettuce": 0.99, "cabbage": 0.99, "cauliflower": 0.99,
    "spinach": 0.99, "celery": 0.99, "asparagus": 0.99, "pumpkin": 0.99,
    "squash": 0.99, "eggplant": 0.99, "radish": 0.99, "beet": 0.99,
    "turnip": 0.99, "yam": 0.99, "mushroom": 0.99, "zucchini": 0.99,
    
    # Makanan & roti
    "bread": 0.95, "bagel": 0.95, "pretzel": 0.95, "dough": 0.95,
    "pizza": 0.95, "hamburger": 0.95, "hotdog": 0.95, "sandwich": 0.95,
    "burrito": 0.95, "taco": 0.95, "cake": 0.95, "donut": 0.95,
    "cookie": 0.95, "pastry": 0.95, "pie": 0.95, "pudding": 0.95,
    "ice_cream": 0.95, "chocolate": 0.95, "candy": 0.95, "crackers": 0.95,
    "noodle": 0.95, "pasta": 0.95, "rice": 0.95, "soup": 0.95,
    "salad": 0.95, "omelet": 0.95, "pancake": 0.95, "waffle": 0.95,
    "toast": 0.95, "croissant": 0.95, "muffin": 0.95, "biscuit": 0.95,
    
    # Daging & protein
    "meat": 0.98, "beef": 0.98, "pork": 0.98, "chicken": 0.98,
    "steak": 0.98, "sausage": 0.98, "bacon": 0.98, "ham": 0.98,
    "fish": 0.98, "salmon": 0.98, "tuna": 0.98, "shrimp": 0.98,
    "crab": 0.98, "lobster": 0.98, "egg": 0.98, "cheese": 0.98,
    "butter": 0.98, "yogurt": 0.98, "milk": 0.95, "cream": 0.95,
    
    # Bahan alami
    "leaf": 0.95, "plant": 0.90, "tree": 0.90, "flower": 0.90,
    "grass": 0.95, "herb": 0.95, "wood": 0.90, "bark": 0.95,
    "twig": 0.95, "branch": 0.95, "root": 0.98, "seed": 0.95,
    "nut": 0.99, "grain": 0.95, "bean": 0.99, "pea": 0.99,
    "lentil": 0.99, "soy": 0.99, "tofu": 0.99,
    
    # Organik lain
    "bone": 0.98, "shell": 0.95, "peel": 0.99, "skin": 0.95,
    "core": 0.99, "pit": 0.99, "stalk": 0.99, "husk": 0.99,
    "pod": 0.99, "stem": 0.95, "petal": 0.95, "root": 0.98,
    "compost": 0.99, "manure": 0.99, "soil": 0.95, "clay": 0.90,
    
    # Makanan olahan (masih organik)
    "sauce": 0.95, "gravy": 0.95, "salsa": 0.95, "dip": 0.95,
    "spread": 0.95, "jam": 0.95, "jelly": 0.95, "honey": 0.99,
    "syrup": 0.95, "oil": 0.95, "vinegar": 0.95, "spice": 0.99,
    "seasoning": 0.99, "flour": 0.95, "sugar": 0.99, "salt": 0.99,
    "coffee": 0.95, "tea": 0.95, "juice": 0.95, "smoothie": 0.95,
}

IMAGENET_ANORGANIC_KEYWORDS = {
    # Plastik & kemasan
    "bottle": 0.97, "plastic": 0.98, "bag": 0.92, "container": 0.97,
    "wrapper": 0.97, "package": 0.95, "packet": 0.95, "pouch": 0.95,
    "sachet": 0.95, "pouch": 0.95, "tub": 0.95, "jug": 0.97,
    "jar": 0.97, "canister": 0.97, "box": 0.90, "carton": 0.90,
    "tray": 0.97, "plate": 0.95, "dish": 0.95, "bowl_disposable": 0.97,
    "cup_disposable": 0.97, "lid": 0.97, "cap": 0.97, "cork": 0.95,
    "cork_stopper": 0.95, "stopper": 0.95, "plug": 0.95,
    
    # Logam
    "can": 0.98, "tin": 0.98, "aluminum": 0.98, "metal": 0.98,
    "steel": 0.98, "iron": 0.98, "copper": 0.98, "brass": 0.98,
    "silver": 0.98, "gold": 0.98, "coin": 0.99, "money": 0.99,
    "cash": 0.99, "currency": 0.99, "bill": 0.99, "banknote": 0.99,
    "token": 0.98, "medal": 0.98, "key": 0.98, "lock": 0.98,
    "chain": 0.98, "nail": 0.98, "screw": 0.98, "bolt": 0.98,
    "nut_hardware": 0.98, "washer": 0.98, "hinge": 0.98, "bracket": 0.98,
    "wire": 0.98, "cable": 0.98, "spring": 0.98, "foil": 0.98,
    "blade": 0.98, "razor": 0.98, "knife": 0.98, "scissors": 0.98,
    "saw": 0.98, "hammer": 0.98, "drill": 0.98, "tool": 0.98,
    "wrench": 0.98, "pliers": 0.98, "screwdriver": 0.98, "axe": 0.98,
    "bucket": 0.97, "pot": 0.95, "pan": 0.97, "kettle": 0.97,
    
    # Kaca
    "glass": 0.98, "mirror": 0.98, "window": 0.98, "lens": 0.98,
    "crystal": 0.98, "ceramic": 0.98, "porcelain": 0.98, "china": 0.98,
    "tile": 0.98, "marble": 0.98, "granite": 0.98, "stone_artificial": 0.98,
    "brick": 0.98, "concrete": 0.98, "cement": 0.98, "plaster": 0.98,
    "vase": 0.98, "bowl_glass": 0.98, "plate_glass": 0.98, "goblet": 0.98,
    "tumbler": 0.98, "beaker": 0.98, "flask": 0.98, "test_tube": 0.98,
    "ampoule": 0.98, "syringe": 0.99, "needle": 0.99, "lancet": 0.99,
    "scalpel": 0.99, "thermometer": 0.99, "pipette": 0.98, "burette": 0.98,
    
    # Elektronik
    "electronic": 0.99, "device": 0.99, "gadget": 0.99, "appliance": 0.99,
    "computer": 0.99, "laptop": 0.99, "tablet": 0.99, "phone": 0.99,
    "smartphone": 0.99, "mobile": 0.99, "charger": 0.99, "adapter": 0.99,
    "battery": 0.99, "power_bank": 0.99, "usb": 0.99, "cable_charger": 0.99,
    "headphone": 0.99, "earphone": 0.99, "speaker": 0.99, "microphone": 0.99,
    "camera": 0.99, "webcam": 0.99, "drone": 0.99, "remote_control": 0.99,
    "mouse_computer": 0.99, "keyboard_computer": 0.99, "monitor": 0.99,
    "printer": 0.99, "scanner": 0.99, "router": 0.99, "modem": 0.99,
    "hard_drive": 0.99, "flash_drive": 0.99, "memory_card": 0.99,
    "circuit": 0.99, "pcb": 0.99, "chip": 0.99, "processor": 0.99,
    "resistor": 0.99, "capacitor": 0.99, "led": 0.99, "diode": 0.99,
    "transistor": 0.99, "transformer": 0.99, "motor": 0.99, "pump": 0.99,
    "fan": 0.99, "heater": 0.99, "ac": 0.99, "air_conditioner": 0.99,
    "refrigerator": 0.99, "freezer": 0.99, "washing_machine": 0.99,
    "dryer": 0.99, "dishwasher": 0.99, "oven": 0.99, "microwave": 0.99,
    "toaster": 0.99, "blender": 0.99, "mixer": 0.99, "grinder": 0.99,
    "iron": 0.99, "vacuum": 0.99, "tv": 0.99, "television": 0.99,
    "radio": 0.99, "dvd": 0.99, "cd_player": 0.99, "vcr": 0.99,
    "game_console": 0.99, "joystick": 0.99, "controller": 0.99,
    "calculator": 0.99, "watch": 0.99, "clock_digital": 0.99, "timer": 0.99,
    "scale": 0.99, "gps": 0.99, "sensor": 0.99, "detector": 0.99,
    
    # Kertas & kardus (ANORGANIK - bisa didaur ulang)
    "paper": 0.85, "cardboard": 0.85, "newspaper": 0.85, "magazine": 0.85,
    "book": 0.85, "notebook": 0.85, "envelope": 0.85, "letter": 0.85,
    "document": 0.85, "ticket": 0.85, "receipt": 0.85, "label": 0.85,
    "tag": 0.85, "poster": 0.85, "flyer": 0.85, "brochure": 0.85,
    "pamphlet": 0.85, "catalog": 0.85, "directory": 0.85, "map_paper": 0.85,
    "blueprint": 0.85, "drawing": 0.85, "photograph_paper": 0.85,
    "napkin_paper": 0.85, "tissue_paper": 0.85, "wipe_paper": 0.85,
    "filter_paper": 0.85, "sandpaper": 0.90, "wallpaper": 0.90,
    "carton_box": 0.85, "pizza_box_clean": 0.85, "egg_carton": 0.85,
    "paper_bag": 0.85, "paper_cup": 0.85, "paper_plate": 0.85,
    "tissue": 0.85, "tissue_paper": 0.85, "kleenex": 0.85,
    "toilet_paper": 0.85, "paper_towel": 0.85, "napkin": 0.85,
    
    # Kain & tekstil
    "fabric": 0.95, "cloth": 0.95, "textile": 0.95, "fiber_synthetic": 0.98,
    "polyester": 0.99, "nylon": 0.99, "acrylic": 0.99, "spandex": 0.99,
    "rayon": 0.95, "lycra": 0.99, "fleece": 0.99, "felt": 0.95,
    "canvas_synthetic": 0.95, "tarp": 0.98, "tent": 0.98, "flag": 0.95,
    "banner": 0.95, "tapestry": 0.95, "curtain": 0.95, "carpet": 0.95,
    "rug": 0.95, "mat": 0.95, "cushion": 0.95, "pillow": 0.95,
    "mattress": 0.95, "towel": 0.92, "blanket": 0.95, "quilt": 0.95,
    "bedsheet": 0.95, "tablecloth": 0.95, "napkin_cloth": 0.92,
    "handkerchief": 0.92, "scarf": 0.95, "glove": 0.95, "mitten": 0.95,
    "sock": 0.95, "stocking": 0.95, "belt": 0.98, "strap": 0.98,
    "ribbon": 0.95, "lace": 0.95, "yarn_synthetic": 0.98, "thread": 0.95,
    "rope": 0.95, "cord": 0.95, "twine": 0.95, "string": 0.95,
    
    # Karet
    "rubber": 0.98, "latex": 0.98, "silicone": 0.98, "eraser": 0.98,
    "rubber_band": 0.98, "balloon": 0.98, "tire": 0.98, "tube_rubber": 0.98,
    "hose": 0.98, "gasket": 0.98, "seal": 0.98, "mat_rubber": 0.98,
    
    # Styrofoam
    "styrofoam": 0.99, "foam": 0.98, "polystyrene": 0.99, "sponge_synthetic": 0.98,
    "cushion_foam": 0.98, "padding": 0.98, "insulation": 0.98,
    
    # Medis/Baterai/Bahan berbahaya
    "medical": 0.99, "medicine": 0.99, "pharmaceutical": 0.99, "drug": 0.99,
    "pill": 0.99, "tablet_medicine": 0.99, "capsule": 0.99, "syrup_medicine": 0.99,
    "antibiotic": 0.99, "vitamin": 0.99, "supplement": 0.99, "ointment": 0.99,
    "cream_medicine": 0.99, "lotion_medicine": 0.99, "bandage": 0.98,
    "plaster": 0.98, "gauze": 0.98, "cotton_medical": 0.98, "swab": 0.98,
    "mask_medical": 0.99, "gloves_medical": 0.99, "apron_medical": 0.98,
    "gown_medical": 0.98, "cap_medical": 0.98, "shield_face": 0.98,
    "iv_bag": 0.99, "iv_tube": 0.99, "catheter": 0.99, "syringe": 0.99,
    "needle_medical": 0.99, "lancet": 0.99, "scalpel": 0.99, "suture": 0.99,
    "vial": 0.99, "ampoule": 0.99, "bottle_medicine": 0.99, "container_sharps": 0.99,
    "xray_film": 0.99, "thermometer_mercury": 0.99, "blood_pressure": 0.99,
    "stethoscope": 0.99, "wheelchair": 0.99, "crutch": 0.98, "walker": 0.98,
    "prosthetic": 0.99, "dental": 0.99, "braces": 0.99, "denture": 0.99,
    "contact_lens": 0.98, "hearing_aid": 0.99, "pacemaker": 0.99,
    "battery": 0.99, "cell_battery": 0.99, "lithium_battery": 0.99,
    "car_battery": 0.99, "battery_pack": 0.99, "power_bank": 0.99,
    "charger": 0.99, "adapter": 0.99, "cable_usb": 0.99, "cable_hdmi": 0.99,
    "cable_power": 0.99, "extension_cord": 0.99, "power_strip": 0.99,
    "light_bulb": 0.99, "fluorescent": 0.99, "led_bulb": 0.99, "neon": 0.99,
    "cfl": 0.99, "halogen": 0.99, "incandescent": 0.99, "tube_light": 0.99,
    "paint": 0.99, "thinner": 0.99, "solvent": 0.99, "varnish": 0.99,
    "stain": 0.99, "lacquer": 0.99, "sealer": 0.99, "adhesive": 0.98,
    "glue": 0.98, "epoxy": 0.99, "resin": 0.99, "pesticide": 0.99,
    "insecticide": 0.99, "herbicide": 0.99, "fungicide": 0.99, "rat_poison": 0.99,
    "cleaner": 0.99, "detergent": 0.99, "bleach": 0.99, "disinfectant": 0.99,
    "polish": 0.99, "wax": 0.99, "oil_motor": 0.99, "antifreeze": 0.99,
    "brake_fluid": 0.99, "transmission_fluid": 0.99, "grease": 0.99,
    "kerosene": 0.99, "gasoline": 0.99, "diesel": 0.99, "propane": 0.99,
    "butane": 0.99, "aerosol": 0.99, "spray_can": 0.99, "perfume": 0.98,
    "cosmetic": 0.98, "makeup": 0.98, "nail_polish": 0.99, "nail_polish_remover": 0.99,
    "hair_spray": 0.99, "deodorant": 0.98, "shampoo_bottle_empty": 0.97,
    "conditioner_bottle_empty": 0.97, "soap_liquid_bottle_empty": 0.97,
    "lotion_bottle_empty": 0.97, "sunscreen_bottle_empty": 0.97,
    "toothpaste_tube_empty": 0.97, "mouthwash_bottle_empty": 0.97,
    
    # CD/DVD/Floppy/Media
    "cd": 0.99, "dvd": 0.99, "blu_ray": 0.99, "disc": 0.99, "vinyl_record": 0.99,
    "cassette": 0.99, "tape": 0.99, "video_tape": 0.99, "reel": 0.99,
    "floppy_disk": 0.99, "memory_card": 0.99, "sd_card": 0.99, "micro_sd": 0.99,
    "sim_card": 0.99, "smart_card": 0.99, "rfid": 0.99, "chip_card": 0.99,
    
    # Lainnya anorganik
    "toy": 0.95, "doll": 0.95, "action_figure": 0.95, "lego": 0.98,
    "block": 0.95, "puzzle": 0.95, "game": 0.95, "ball": 0.95,
    "football": 0.95, "basketball": 0.95, "baseball": 0.95, "tennis_ball": 0.95,
    "golf_ball": 0.95, "soccer_ball": 0.95, "volleyball": 0.95, "frisbee": 0.95,
    "kite": 0.95, "yo_yo": 0.95, "marble": 0.98, "domino": 0.95,
    "card_playing": 0.90, "dice": 0.98, "chess_piece": 0.95, "checker": 0.95,
    "poker_chip": 0.98, "coin": 0.99, "token": 0.98, "medal": 0.98,
    "trophy": 0.98, "award": 0.98, "plaque": 0.98, "ornament": 0.95,
    "decoration": 0.95, "frame": 0.95, "clock": 0.98, "watch": 0.98,
    "jewelry": 0.98, "ring": 0.98, "necklace": 0.98, "bracelet": 0.98,
    "earring": 0.98, "pendant": 0.98, "brooch": 0.98, "cufflink": 0.98,
    "tie_clip": 0.98, "hairpin": 0.98, "comb": 0.98, "brush": 0.98,
    "mirror": 0.98, "lamp": 0.98, "lantern": 0.98, "candle_holder": 0.98,
    "ashtray": 0.98, "vase": 0.98, "pottery": 0.98, "urn": 0.98,
    "basket_wicker": 0.92, "bamboo_item": 0.92, "wooden_item_coated": 0.95,
    "cork": 0.95, "sponge": 0.92, "loofah": 0.90, "pumice": 0.95,
    "charcoal_briquette": 0.95, "coal": 0.95, "ash": 0.95,
}

# ================================================================
# 3. TEXTURE-BASED CLASSIFICATION RULES
# ================================================================

# Aturan berdasarkan tekstur untuk edge cases
TEXTURE_RULES = {
    # Format: (kehalusan, kekasaran, kelembutan, kekerasan)
    # High softness + low roughness = kemungkinan kain/sponge/organik lembut
    # High roughness + low softness = kemungkinan logam/kaca/plastik kasar
    "soft_smooth_organic": {
        "smoothness_range": (0.3, 1.0),
        "roughness_range": (0.0, 0.4),
        "softness_range": (0.6, 1.0),
        "category": "ORGANIK",
        "confidence_boost": 0.15,
        "reason": "Tekstur lembut dan halus mengindikasikan bahan organik",
    },
    "hard_smooth_anorganic": {
        "smoothness_range": (0.6, 1.0),
        "roughness_range": (0.0, 0.3),
        "softness_range": (0.0, 0.3),
        "category": "ANORGANIK",
        "confidence_boost": 0.20,
        "reason": "Tekstur keras dan halus mengindikasikan plastik/kaca/logam",
    },
    "rough_hard_anorganic": {
        "smoothness_range": (0.0, 0.5),
        "roughness_range": (0.5, 1.0),
        "softness_range": (0.0, 0.4),
        "category": "ANORGANIK",
        "confidence_boost": 0.15,
        "reason": "Tekstur kasar dan keras mengindikasikan logam/keramik",
    },
    "soft_fuzzy_organic": {
        "smoothness_range": (0.0, 0.5),
        "roughness_range": (0.3, 0.8),
        "softness_range": (0.5, 1.0),
        "category": "ORGANIK",
        "confidence_boost": 0.10,
        "reason": "Tekstur lembut dan berbulu mengindikasikan bahan organik",
    },
}

# ================================================================
# 4. COLOR-BASED HEURISTICS (HSV)
# ================================================================

# Rentang warna yang mengindikasikan organik
ORGANIC_COLOR_PROFILES = {
    "green_fresh": {"h": (30, 85), "s": (40, 255), "v": (50, 255)},
    "brown_earth": {"h": (10, 30), "s": (30, 255), "v": (30, 200)},
    "yellow_fruit": {"h": (20, 35), "s": (50, 255), "v": (80, 255)},
    "red_fruit": {"h": (0, 10), "s": (50, 255), "v": (50, 255)},
    "red_fruit2": {"h": (160, 180), "s": (50, 255), "v": (50, 255)},
    "orange_fruit": {"h": (10, 25), "s": (60, 255), "v": (80, 255)},
    "white_beige_food": {"h": (0, 50), "s": (0, 50), "v": (150, 255)},
}

# Rentang warna yang mengindikasikan anorganik
ANORGANIC_COLOR_PROFILES = {
    "blue_plastic": {"h": (100, 140), "s": (40, 255), "v": (50, 255)},
    "gray_metal": {"h": (0, 180), "s": (0, 30), "v": (40, 200)},
    "transparent_glass": {"h": (0, 180), "s": (0, 30), "v": (150, 255)},
    "black_plastic": {"h": (0, 180), "s": (0, 50), "v": (0, 40)},
    "white_paper_clean": {"h": (0, 50), "s": (0, 20), "v": (200, 255)},
    "neon_synthetic": {"h": (0, 180), "s": (150, 255), "v": (150, 255)},
    "silver_chrome": {"h": (0, 180), "s": (0, 20), "v": (100, 255)},
    "gold": {"h": (15, 35), "s": (100, 255), "v": (100, 255)},
    "copper": {"h": (5, 20), "s": (80, 255), "v": (50, 200)},
}

# ================================================================
# 5. KATEGORI DESKRIPSI LENGKAP
# ================================================================

CATEGORY_INFO = {
    "ORGANIK": {
        "label": "SAMPAH ORGANIK",
        "label_short": "ORGANIK",
        "icon": "🍃",
        "color_hex": "#22C55E",
        "color_bgr": (34, 197, 94),
        "bin_color": "HIJAU",
        "description": (
            "Sampah ORGANIK terdeteksi! Sampah ini dapat terurai secara alami "
            "oleh mikroorganisme dan cocok dijadikan kompos. "
            "Contoh: sisa makanan, buah, sayur, daun, kulit buah, tulang, "
            "ranting kayu, kertas bekas makanan (basah/minyak), dan bahan organik lainnya. "
            "Waktu penguraian: 2-6 bulan."
        ),
        "action": "🟢 Masukkan ke TEMPAT SAMPAH HIJAU (Organik)",
        "serial_cmd": "O",
        "examples": [
            "Sisa nasi/makanan", "Kulit buah", "Sayuran busuk", "Daun kering",
            "Tulang ikan/ayam", "Kertas bekas makanan (basah)", "Ampas kopi/teh",
            "Ranting kecil", "Bunga layu", "Cangkang telam",
        ],
    },
    "ANORGANIK": {
        "label": "SAMPAH ANORGANIK",
        "label_short": "ANORGANIK",
        "icon": "♻️",
        "color_hex": "#EF4444",
        "color_bgr": (68, 68, 239),
        "bin_color": "MERAH",
        "description": (
            "Sampah ANORGANIK terdeteksi! Sampah ini TIDAK DAPAT terurai secara alami "
            "atau memerlukan waktu sangat lama (ratusan tahun). "
            "Contoh: plastik, kaca, logam, kertas uang, koin, elektronik, baterai, "
            "styrofoam, kain sintetis, karet, keramik, alat medis, dll. "
            "Waktu penguraian: 50-1000+ tahun. Harus didaur ulang atau diolah khusus."
        ),
        "action": "🔴 Masukkan ke TEMPAT SAMPAH MERAH (Anorganik)",
        "serial_cmd": "N",
        "examples": [
            "Botol plastik", "Kaca pecah", "Kaleng", "Kertas uang",
            "Koin/logam", "Elektronik/baterai", "Styrofoam", "Kain sintetis",
            "Karet", "Alat medis (jarum suntik, dll)",
        ],
    },
}

# ================================================================
# 6. EDGE CASES - Objek yang memerlukan analisis khusus
# ================================================================

EDGE_CASE_OBJECTS = {
    # Objek yang bisa organik atau anorganik tergantung kondisi
    "paper": {
        "default": "ANORGANIK",
        "organic_if": ["basah", "minyak", "makanan", "nasi", "sisa"],
        "confidence": 0.80,
    },
    "tissue": {
        "default": "ANORGANIK",
        "organic_if": ["basah", "makanan", "minyak", "bekas"],
        "confidence": 0.75,
    },
    "cardboard": {
        "default": "ANORGANIK",
        "organic_if": ["basah", "minyak", "makanan", "pizza_box_beckas"],
        "confidence": 0.85,
    },
    "wood": {
        "default": "ANORGANIK",  # kayu olahan/dilapisi
        "organic_if": ["mentah", "ranting", "kulit_kayu", "serpih"],
        "confidence": 0.80,
    },
    "cloth": {
        "default": "ANORGANIK",  # kain sintetis dominan
        "organic_if": ["100%_katun_alami", "linen_murni", "wol_murni", "sutra"],
        "confidence": 0.85,
    },
    "cotton": {
        "default": "ORGANIK",
        "organic_if": ["kapas_alami", "bunga_kapas"],
        "confidence": 0.75,
    },
}

# ================================================================
# 7. FUNGSI HELPER
# ================================================================

def get_category_info(category: str) -> Dict:
    """Ambil informasi lengkap kategori."""
    return CATEGORY_INFO.get(category.upper(), CATEGORY_INFO["ANORGANIK"])


def is_organic_keyword(keyword: str) -> Tuple[bool, float]:
    """Cek apakah keyword termasuk organik."""
    kw_lower = keyword.lower().strip()
    for key, conf in IMAGENET_ORGANIC_KEYWORDS.items():
        if key in kw_lower or kw_lower in key:
            return True, conf
    return False, 0.0


def is_anorganic_keyword(keyword: str) -> Tuple[bool, float]:
    """Cek apakah keyword termasuk anorganik."""
    kw_lower = keyword.lower().strip()
    for key, conf in IMAGENET_ANORGANIC_KEYWORDS.items():
        if key in kw_lower or kw_lower in key:
            return True, conf
    return False, 0.0


def classify_by_keyword_ensemble(keyword: str) -> Tuple[str, float, str]:
    """
    Klasifikasi berdasarkan keyword dengan confidence score.
    Returns: (kategori, confidence, reason)
    """
    kw_lower = keyword.lower().strip()
    
    # Cek organik
    is_org, conf_org = is_organic_keyword(keyword)
    # Cek anorganik
    is_anorg, conf_anorg = is_anorganic_keyword(keyword)
    
    if is_org and not is_anorg:
        return "ORGANIK", conf_org, f"Keyword '{keyword}' terdaftar sebagai organik"
    elif is_anorg and not is_org:
        return "ANORGANIK", conf_anorg, f"Keyword '{keyword}' terdaftar sebagai anorganik"
    elif is_org and is_anorg:
        # Ambil yang confidence lebih tinggi
        if conf_org >= conf_anorg:
            return "ORGANIK", conf_org * 0.85, f"Ambiguous '{keyword}', leaning ORGANIK (conf: {conf_org:.2f} vs {conf_anorg:.2f})"
        else:
            return "ANORGANIK", conf_anorg * 0.85, f"Ambiguous '{keyword}', leaning ANORGANIK (conf: {conf_anorg:.2f} vs {conf_org:.2f})"
    else:
        return "UNKNOWN", 0.0, f"Keyword '{keyword}' tidak terdaftar"


def get_all_keywords() -> List[str]:
    """Dapatkan semua keyword yang terdaftar."""
    org = list(IMAGENET_ORGANIC_KEYWORDS.keys())
    anorg = list(IMAGENET_ANORGANIC_KEYWORDS.keys())
    yolo = list(YOLO_WASTE_MAPPING.keys())
    return list(set(org + anorg + yolo))


# ================================================================
# 8. STATISTIK DATABASE
# ================================================================

def get_database_stats() -> Dict:
    """Dapatkan statistik database."""
    return {
        "total_organic_keywords": len(IMAGENET_ORGANIC_KEYWORDS),
        "total_anorganic_keywords": len(IMAGENET_ANORGANIC_KEYWORDS),
        "total_yolo_mappings": len(YOLO_WASTE_MAPPING),
        "total_edge_cases": len(EDGE_CASE_OBJECTS),
        "total_color_profiles_org": len(ORGANIC_COLOR_PROFILES),
        "total_color_profiles_anorg": len(ANORGANIC_COLOR_PROFILES),
        "total_texture_rules": len(TEXTURE_RULES),
        "total_unique_objects": len(
            set(list(IMAGENET_ORGANIC_KEYWORDS.keys()) + 
                list(IMAGENET_ANORGANIC_KEYWORDS.keys()) +
                list(YOLO_WASTE_MAPPING.keys()))
        ),
    }


if __name__ == "__main__":
    stats = get_database_stats()
    print("📊 DATABASE PENGETAHUAN SAMPAH")
    print("=" * 50)
    for key, val in stats.items():
        print(f"  {key}: {val}")
    print("=" * 50)
    print("\n✅ Database siap digunakan!")
