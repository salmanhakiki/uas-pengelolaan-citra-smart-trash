@echo off
chcp 65001 >nul
title Smart Trash Sorter - Setup Environment
cls

echo ============================================================
echo   SMART TRASH SORTER v3.0 - SETUP ENVIRONMENT
echo ============================================================
echo.

:: ============================================================
:: CEK PYTHON
:: ============================================================
echo [1/5] Mengecek Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo [X] Python tidak ditemukan!
    echo.
    echo [INFO] Silakan install Python 3.9 - 3.12 dari:
    echo    https://www.python.org/downloads/
    echo.
    echo [WARNING] Penting: Centang "Add Python to PATH" saat instalasi!
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%a in ('python --version 2^>^&1') do set PYTHON_VER=%%a
echo [OK] %PYTHON_VER% ditemukan.

:: ============================================================
:: CEK PIP
:: ============================================================
echo [2/5] Mengecek pip...
python -m pip --version >nul 2>&1
if errorlevel 1 (
    echo [X] pip tidak ditemukan! Menginstall...
    python -m ensurepip --upgrade
)
echo [OK] pip siap.

:: ============================================================
:: UPGRADE PIP
:: ============================================================
echo [3/5] Upgrade pip...
python -m pip install --upgrade pip setuptools wheel -q
echo [OK] pip upgraded.

:: ============================================================
:: INSTALL REQUIREMENTS
:: ============================================================
echo [4/5] Install dependencies...
echo     [INFO] Ini akan memakan waktu beberapa menit...
echo     [INFO] TensorFlow (~500MB), Ultralytics, OpenCV, dll.
echo.
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [X] Gagal install dependencies!
    echo    Coba jalankan sebagai Administrator.
    echo.
    pause
    exit /b 1
)
echo [OK] Semua dependencies terinstall!

:: ============================================================
:: DOWNLOAD MODEL WEIGHTS (pre-download)
:: ============================================================
echo [5/5] Download model weights...
echo     [INFO] Download YOLOv8n weights (~6MB)...
python -c "from ultralytics import YOLO; YOLO('yolov8n.pt')" 2>nul
echo     [OK] YOLOv8n weights siap.

echo     [INFO] Download EfficientNetB0 weights (~50MB)...
python -c "from tensorflow.keras.applications import EfficientNetB0; EfficientNetB0(weights='imagenet')" 2>nul
echo     [OK] EfficientNetB0 weights siap.

:: ============================================================
:: SELESAI
:: ============================================================
echo.
echo ============================================================
echo   [OK] SETUP SELESAI!
echo ============================================================
echo.
echo [INFO] Untuk menjalankan aplikasi, double-click:
echo    run_app.bat
echo.
echo [INFO] Atau jalankan manual:
echo    streamlit run app.py
echo.
pause
