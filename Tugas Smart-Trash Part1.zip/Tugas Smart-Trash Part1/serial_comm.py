"""
serial_comm.py
─────────────────────────────────────────────────────────────
Manajemen komunikasi serial dengan ESP8266.
Auto-detect port, reconnect otomatis, thread-safe.
─────────────────────────────────────────────────────────────
"""

import serial
import serial.tools.list_ports
import threading
import time
import logging
from typing import Optional, List

logger = logging.getLogger(__name__)


class ESP8266Comm:
    """
    Wrapper thread-safe untuk komunikasi serial dengan ESP8266.
    Fitur:
    - Auto-detect port COM
    - Reconnect otomatis jika koneksi terputus
    - Timeout handling
    - Mode simulasi jika ESP tidak terhubung (debug)
    """

    BAUD_RATE = 115200
    TIMEOUT   = 2.0    # detik
    RECONNECT_INTERVAL = 5  # detik

    def __init__(self):
        self._ser: Optional[serial.Serial] = None
        self._lock = threading.Lock()
        self._connected = False
        self._port = None
        self._simulation_mode = False

    # ── Deteksi Port ─────────────────────────────────────────

    @staticmethod
    def list_available_ports() -> List[str]:
        """Daftar semua port serial yang tersedia."""
        ports = serial.tools.list_ports.comports()
        return [p.device for p in ports]

    @staticmethod
    def auto_detect_esp_port() -> Optional[str]:
        """
        Coba deteksi otomatis port ESP8266/CH340.
        Prioritas: CH340, CP210x, USB Serial, lalu COM3/COM4.
        """
        ports = serial.tools.list_ports.comports()

        # Chip yang umum dipakai ESP8266
        ESP_KEYWORDS = ["ch340", "cp210", "usb serial", "uart", "esp", "wemos", "nodemcu"]

        for port in ports:
            desc = (port.description or "").lower()
            mfg  = (port.manufacturer or "").lower()
            if any(kw in desc or kw in mfg for kw in ESP_KEYWORDS):
                logger.info(f"ESP8266 terdeteksi di: {port.device} ({port.description})")
                return port.device

        # Fallback: coba COM3 dan COM4
        for fallback in ["COM3", "COM4", "COM5", "/dev/ttyUSB0", "/dev/ttyUSB1"]:
            for port in ports:
                if port.device == fallback:
                    return fallback

        return None

    # ── Koneksi ──────────────────────────────────────────────

    def connect(self, port: Optional[str] = None) -> bool:
        """
        Buka koneksi serial.
        Jika port=None, auto-detect.
        Returns True jika berhasil.
        """
        with self._lock:
            target_port = port or self.auto_detect_esp_port()

            if not target_port:
                logger.warning("Tidak ada port ESP8266 ditemukan. Mode Simulasi aktif.")
                self._simulation_mode = True
                self._connected = True
                return True

            try:
                if self._ser and self._ser.is_open:
                    self._ser.close()

                self._ser = serial.Serial(
                    port=target_port,
                    baudrate=self.BAUD_RATE,
                    timeout=self.TIMEOUT,
                    write_timeout=self.TIMEOUT,
                )
                time.sleep(2)  # Tunggu ESP8266 reset setelah koneksi

                # Ping ESP
                self._ser.write(b'P')
                self._ser.flush()
                time.sleep(0.5)
                response = self._ser.readline().decode("utf-8", errors="ignore").strip()

                if "READY" in response:
                    self._connected = True
                    self._port = target_port
                    self._simulation_mode = False
                    logger.info(f"✅ ESP8266 terhubung di {target_port}")
                    return True
                else:
                    logger.warning(f"ESP8266 tidak merespons READY. Response: {response}")
                    # Tetap anggap terhubung (mungkin masalah timing)
                    self._connected = True
                    self._port = target_port
                    self._simulation_mode = False
                    return True

            except serial.SerialException as e:
                logger.error(f"Gagal membuka port {target_port}: {e}")
                self._simulation_mode = True
                self._connected = True
                return False

    def disconnect(self):
        """Tutup koneksi serial."""
        with self._lock:
            if self._ser and self._ser.is_open:
                self._ser.close()
            self._connected = False
            self._ser = None
            logger.info("Koneksi serial ditutup.")

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def is_simulation(self) -> bool:
        return self._simulation_mode

    @property
    def port(self) -> Optional[str]:
        return self._port

    # ── Kirim Perintah ───────────────────────────────────────

    def send_command(self, command: str) -> str:
        """
        Kirim perintah ke ESP8266 dan tunggu ACK.

        Args:
            command: 'O' (organik), 'N' (anorganik), 'R' (reset), 'P' (ping)

        Returns:
            String respons dari ESP, atau "SIM:..." jika mode simulasi
        """
        if self._simulation_mode:
            sim_responses = {
                "O": "SIM:ACK:ORGANIC - [SIMULASI] Servo → 45°, Buzzer 1x",
                "N": "SIM:ACK:ANORGANIC - [SIMULASI] Servo → 135°, Buzzer 2x",
                "R": "SIM:ACK:RESET - [SIMULASI] Servo → 90°",
                "P": "READY",
            }
            time.sleep(0.3)  # simulasi delay
            return sim_responses.get(command, "SIM:ACK:UNKNOWN")

        with self._lock:
            if not self._ser or not self._ser.is_open:
                return "ERROR:NOT_CONNECTED"

            try:
                # Bersihkan buffer
                self._ser.reset_input_buffer()

                # Kirim perintah
                self._ser.write(command.encode("utf-8"))
                self._ser.flush()

                # Tunggu ACK (maksimal TIMEOUT detik)
                response = self._ser.readline().decode("utf-8", errors="ignore").strip()
                return response if response else "NO_RESPONSE"

            except serial.SerialTimeoutException:
                return "ERROR:TIMEOUT"
            except serial.SerialException as e:
                logger.error(f"Error serial: {e}")
                self._connected = False
                return f"ERROR:{e}"

    def send_sort_command(self, category: str) -> str:
        """
        Kirim perintah sorting berdasarkan kategori.

        Args:
            category: "ORGANIK" atau "ANORGANIK"

        Returns:
            Response string dari ESP8266
        """
        cmd_map = {
            "ORGANIK": "O",
            "ANORGANIK": "N",
        }
        cmd = cmd_map.get(category.upper(), "R")
        return self.send_command(cmd)

    def send_reset(self) -> str:
        """Reset servo ke posisi tengah."""
        return self.send_command("R")

    def ping(self) -> bool:
        """Cek apakah ESP8266 masih responsif."""
        resp = self.send_command("P")
        return "READY" in resp or "SIM:" in resp


# ── Singleton global ─────────────────────────────────────────
_esp_instance: Optional[ESP8266Comm] = None


def get_esp() -> ESP8266Comm:
    """Dapatkan instance singleton ESP8266Comm."""
    global _esp_instance
    if _esp_instance is None:
        _esp_instance = ESP8266Comm()
    return _esp_instance
