"""
smart_classifier.py
================================================================
ULTIMATE FIX: DUAL-ENSEMBLE AI (ANTI-SALAH DETEKSI DAUN & UANG)
================================================================
"""
import torch
import torchvision.models as models
import torchvision.transforms as transforms
import cv2
import numpy as np
from PIL import Image

class SmartClassifier:
    def __init__(self):
        # 1. Load Model Kelas Berat (ResNet-101)
        self.weights_resnet = models.ResNet101_Weights.DEFAULT
        self.model_resnet = models.resnet101(weights=self.weights_resnet)
        self.model_resnet.eval()
        
        # 2. Load Model Cepat (MobileNet-V3)
        self.weights_mobile = models.MobileNet_V3_Large_Weights.DEFAULT
        self.model_mobile = models.mobilenet_v3_large(weights=self.weights_mobile)
        self.model_mobile.eval()
        
        self.categories = self.weights_resnet.meta["categories"]
        
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])

    def _is_organic_material(self, cv2_img):
        """
        HEURISTIK WARNA: Mendeteksi daun segar (hijau) MAUPUN daun kering (cokelat/kuning).
        """
        try:
            hsv = cv2.cvtColor(cv2_img, cv2.COLOR_BGR2HSV)
            
            # 1. Filter Hijau (Daun Segar/Sayur)
            lower_green = np.array([35, 20, 20])
            upper_green = np.array([85, 255, 255])
            mask_green = cv2.inRange(hsv, lower_green, upper_green)
            
            # 2. Filter Cokelat/Kuning Tulen (Daun Kering/Ranting)
            lower_brown = np.array([10, 30, 30])
            upper_brown = np.array([30, 255, 200])
            mask_brown = cv2.inRange(hsv, lower_brown, upper_brown)
            
            # Gabungkan kedua filter
            mask_organic = cv2.bitwise_or(mask_green, mask_brown)
            
            organic_pixels = np.sum(mask_organic == 255)
            total_pixels = cv2_img.shape[0] * cv2_img.shape[1]
            percentage = (organic_pixels / total_pixels) * 100
            
            return percentage > 12.0  # Toleransi sensitivitas area
        except Exception:
            return False

    def predict(self, cv2_img):
        if cv2_img is None:
            return {'category': 'UNKNOWN', 'confidence_pct': '0%', 'object': 'Tidak ada'}
        
        # Proses Jalur Deep Learning Tensor
        img_rgb = cv2.cvtColor(cv2_img, cv2.COLOR_BGR2RGB)
        tensor_img = self.transform(img_rgb).unsqueeze(0)
        
        with torch.no_grad():
            out_resnet = self.model_resnet(tensor_img)
            prob_resnet = torch.nn.functional.softmax(out_resnet[0], dim=0)
            
            out_mobile = self.model_mobile(tensor_img)
            prob_mobile = torch.nn.functional.softmax(out_mobile[0], dim=0)
            
            # Gabungkan nilai dari kedua model AI
            combined_prob = (prob_resnet + prob_mobile) / 2.0
            
        top_prob, top_cat_id = torch.topk(combined_prob, 1)
        confidence = top_prob.item()
        detected_object = self.categories[top_cat_id.item()]
        
        # Mapping teks hasil prediksi awal ke kategori sampah
        kategori = self._map_to_waste_category(detected_object)
        object_title = detected_object.title()
        
        # 🔥 DOUBLE SAFETY OVERRIDE UNTUK DAUN/VEGETASI
        if self._is_organic_material(cv2_img):
            # Jika AI mendeteksi kemiripan kertas/kemasan tapi warnanya daun/cokelat kayu, paksa ke ORGANIK
            if kategori == "ANORGANIK" and any(x in detected_object.lower() for x in ['packet', 'envelope', 'web site', 'menu']):
                kategori = "ORGANIK"
                object_title = f"{object_title} (Koreksi Tekstur Organik)"
        
        return {
            'category': kategori,
            'confidence_pct': f"{confidence * 100:.1f}%",
            'object': f"{object_title} (Dual-Ensemble)"
        }

    def _map_to_waste_category(self, label):
        label = label.lower()
        
        # FIX: Pindahkan 'money', 'cash', 'bill', 'banknote' total ke ORGANIK!
        # Tambahkan semua variasi kertas, amplop, koran, tisu, dan buku.
        organik_keywords = [
            # Komponen Utama Kertas & Uang (Selulosa/Kapas)
            'banknote', 'bill', 'cash', 'money', 'paper', 'tissue', 'napkin', 
            'towel', 'cardboard', 'carton', 'envelope', 'book', 'notebook', 
            'ledger', 'magazine', 'comic', 'menu',
            # Tumbuhan & Daun (Segala Jenis Spesies ImageNet)
            'leaf', 'leaves', 'plant', 'flower', 'grass', 'tree', 'bark', 'twig', 
            'stick', 'root', 'clover', 'buckeye', 'cardoon', 'fern', 'moss', 
            'shrub', 'bush', 'vegetation', 'foliage', 'pot', 'potted plant',
            # Makanan & Makhluk Hidup
            'banana', 'apple', 'orange', 'lemon', 'fruit', 'vegetable', 'meat',
            'bread', 'food', 'egg', 'nut', 'seed', 'mushroom', 'fungus', 'animal', 
            'fish', 'bird', 'rice', 'bean', 'corn', 'potato', 'tomato', 'broccoli', 'cabbage'
        ]
        
        anorganik_keywords = [
            'can', 'bottle', 'bottlecap', 'cup', 'wrapper', 'plastic', 'bag', 
            'box', 'container', 'tin', 'metal', 'glass', 'jar', 'lighter', 
            'battery', 'wire', 'cable', 'screw', 'nail', 'tool', 'foil', 
            'tub', 'electronic', 'keyboard', 'mouse', 'phone', 'screen', 'monitor',
            'iron', 'steel', 'aluminum', 'copper', 'rubber', 'foam', 'sponge',
            'synthetic', 'nylon', 'polyester', 'ceramic', 'porcelain', 'mug',
            'plate', 'bowl', 'fork', 'spoon', 'knife', 'pen', 'pencil', 'ruler',
            'tape', 'glue', 'cd', 'disc', 'helmet', 'glove', 'shoe', 'boot',
            'coin', 'toy', 'doll', 'car'
        ]
        
        # Cek kecocokan Organik duluan agar aman
        for kw in organik_keywords:
            if kw in label: 
                return "ORGANIK"
                
        for kw in anorganik_keywords:
            if kw in label: 
                return "ANORGANIK"
            
        return "ANORGANIK"

def get_classifier():
    return SmartClassifier()